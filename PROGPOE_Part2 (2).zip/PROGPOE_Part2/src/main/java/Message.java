import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

public class Message {

    private String messageID;
    private int numMessagesSent;
    private String recipient;
    private String messageText;
    private String messageHash;

    private static List<Message> sentMessages = new ArrayList<>();
    private static List<Message> storedMessages = new ArrayList<>();
    private static int totalMessagesSent = 0;

    public Message() {}

    public Message(String recipient, String messageText, int numMessagesSent) {
        this.numMessagesSent = numMessagesSent;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    private String generateMessageID() {
        Random random = new Random();
        long id = (long) (random.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    public boolean checkMessageID() {
        if (messageID == null) return false;
        return messageID.length() <= 10;
    }

    public String checkRecipientCell() {
        if (recipient == null || !recipient.startsWith("+") || recipient.length() > 10) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        return "Cell phone number successfully captured.";
    }

    public String createMessageHash() {
        if (messageID == null || messageText == null) return "";

        String firstTwo = messageID.substring(0, Math.min(2, messageID.length()));

        String[] words = messageText.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0].replaceAll("[^a-zA-Z0-9]", "") : "";
        String lastWord  = words.length > 1 ? words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "") : firstWord;

        return (firstTwo + ":" + numMessagesSent + ":" + (firstWord + lastWord).toUpperCase());
    }

    public String SentMessage() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nWhat would you like to do with this message?");
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        System.out.print("Choose an option: ");

        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1":
                sentMessages.add(this);
                totalMessagesSent++;
                return "Message successfully sent.";
            case "2":
                System.out.println("Press 0 to delete the message");
                scanner.nextLine();
                return "Press 0 to delete the message";
            case "3":
                storedMessages.add(this);
                return "Message successfully stored.";
            default:
                return "Invalid option. Message not sent.";
        }
    }

    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages sent yet.";
        }
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID:   ").append(m.messageID).append("\n");
            sb.append("Message Hash: ").append(m.messageHash).append("\n");
            sb.append("Recipient:    ").append(m.recipient).append("\n");
            sb.append("Message:      ").append(m.messageText).append("\n");
            sb.append("─────────────────────────\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessagess() {
        return totalMessagesSent;
    }

        public static void storeMessage() {
        StringBuilder json = new StringBuilder("[\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            Message m = storedMessages.get(i);
            json.append("  {\n");
            json.append("    \"messageID\": \"").append(m.messageID).append("\",\n");
            json.append("    \"numMessagesSent\": ").append(m.numMessagesSent).append(",\n");
            json.append("    \"recipient\": \"").append(m.recipient).append("\",\n");
            json.append("    \"message\": \"").append(m.messageText.replace("\"", "\\\"")).append("\",\n");
            json.append("    \"messageHash\": \"").append(m.messageHash).append("\"\n");
            json.append("  }");
            if (i < storedMessages.size() - 1) json.append(",");
            json.append("\n");
        }
        json.append("]");

        try (FileWriter file = new FileWriter("stored_messages.json")) {
            file.write(json.toString());
            System.out.println("Messages saved to stored_messages.json");
        } catch (IOException e) {
            System.out.println("Error saving messages: " + e.getMessage());
        }
    }

    public static String validateMessage(String text) {
        if (text.length() > 250) {
            int excess = text.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
        return "Message ready to send.";
    }

    public String getMessageID()    { return messageID; }
    public String getMessageHash()  { return messageHash; }
    public String getRecipient()    { return recipient; }
    public String getMessageText()  { return messageText; }
    public int getNumMessagesSent() { return numMessagesSent; }

    public void setMessageID(String id)      { this.messageID = id; }
    public void setRecipient(String r)       { this.recipient = r; }
    public void setMessageText(String t)     { this.messageText = t; }
    public void setNumMessagesSent(int n)    { this.numMessagesSent = n; }

    public static void resetState() {
        sentMessages.clear();
        storedMessages.clear();
        totalMessagesSent = 0;
    }
}
