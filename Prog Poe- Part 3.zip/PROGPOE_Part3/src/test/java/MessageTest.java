import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {

    // ── Test data matching the assignment spec ──
    private Message msg1, msg2, msg3, msg4, msg5;

    @Before
    public void setUp() {
        Message.resetState();

        // Message 1 — Sent
        msg1 = new Message("+27834557896", "Did you get the cake?", 0);
        Message.addToSent(msg1);

        // Message 2 — Stored
        msg2 = new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", 1);
        Message.addToStored(msg2);

        // Message 3 — Disregarded
        msg3 = new Message("+27834484567", "Yohoooo, I am at your gate.", 2);
        Message.addToDisregarded(msg3);

        // Message 4 — Sent  (Developer: recipient number without + — treated as invalid but flag=Sent per spec)
        msg4 = new Message("0838884567", "It is dinner time!", 3);
        Message.addToSent(msg4);

        // Message 5 — Stored
        msg5 = new Message("+27838884567", "Ok, I am leaving without you.", 4);
        Message.addToStored(msg5);
    }

    // ─────────────────────────────────────────────
    // 1. Sent Messages array correctly populated
    // System returns: "Did you get the cake?", "It is dinner time!"
    // ─────────────────────────────────────────────
    @Test
    public void testSentMessagesArrayPopulated() {
        assertEquals(2, Message.getSentMessages().size());
        assertEquals("Did you get the cake?",  Message.getSentMessages().get(0).getMessageText());
        assertEquals("It is dinner time!",     Message.getSentMessages().get(1).getMessageText());
    }

    // ─────────────────────────────────────────────
    // 2. Display the longest message
    // Test data messages 1–4 → longest = msg2
    // ─────────────────────────────────────────────
    @Test
    public void testLongestMessage() {
        String longest = Message.getLongestMessage();
        assertEquals("Where are you? You are late! I have asked you to be on time.", longest);
    }

    // ─────────────────────────────────────────────
    // 3. Search for message by ID
    // Test data: message 4 (0838884567) → "It is dinner time!"
    // ─────────────────────────────────────────────
    @Test
    public void testSearchByMessageID_Found() {
        String result = Message.searchByMessageID(msg4.getMessageID());
        assertTrue(result.contains("It is dinner time!"));
    }

    @Test
    public void testSearchByMessageID_NotFound() {
        String result = Message.searchByMessageID("0000000000");
        assertEquals("Message ID not found.", result);
    }

    // ─────────────────────────────────────────────
    // 4. Search all messages for a particular recipient
    // Test data: +27838884567 → msg2 and msg5
    // ─────────────────────────────────────────────
    @Test
    public void testSearchByRecipient_Found() {
        String result = Message.searchByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testSearchByRecipient_NotFound() {
        String result = Message.searchByRecipient("+00000000000");
        assertEquals("No messages found for that recipient.", result);
    }

    // ─────────────────────────────────────────────
    // 5. Delete a message using message hash
    // ─────────────────────────────────────────────
    @Test
    public void testDeleteByHash_Success() {
        String hash = msg1.getMessageHash();
        String result = Message.deleteByHash(hash);
        assertTrue(result.contains("successfully deleted"));
        assertEquals(1, Message.getSentMessages().size()); // was 2, now 1
    }

    @Test
    public void testDeleteByHash_NotFound() {
        String result = Message.deleteByHash("FAKEHASH");
        assertEquals("Message hash not found.", result);
    }

    // ─────────────────────────────────────────────
    // 6. Message length validation
    // ─────────────────────────────────────────────
    @Test
    public void testMessageLength_Success() {
        assertEquals("Message ready to send.", Message.validateMessage("Did you get the cake?"));
    }

    @Test
    public void testMessageLength_Failure() {
        String longMsg = "a".repeat(260);
        String result = Message.validateMessage(longMsg);
        assertTrue(result.contains("Message exceeds 250 characters by 10"));
    }

    // ─────────────────────────────────────────────
    // 7. Recipient cell number validation
    // ─────────────────────────────────────────────
    @Test
    public void testRecipientCell_Success() {
        Message m = new Message();
        m.setRecipient("+277186930"); // 10 chars, starts with +
        assertEquals("Cell phone number successfully captured.", m.checkRecipientCell());
    }

    @Test
    public void testRecipientCell_FailNoPlus() {
        Message m = new Message();
        m.setRecipient("0838884567"); // no + prefix
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            m.checkRecipientCell()
        );
    }

    @Test
    public void testRecipientCell_FailTooLong() {
        Message m = new Message();
        m.setRecipient("+27838884567"); // 12 chars
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            m.checkRecipientCell()
        );
    }

    // ─────────────────────────────────────────────
    // 8. Message hash is correct
    // msg1: "Did you get the cake?" → DID:CAKE (first word + last word)
    // ─────────────────────────────────────────────
    @Test
    public void testMessageHash_Format() {
        Message m = new Message();
        m.setMessageID("0012345678");
        m.setNumMessagesSent(0);
        m.setMessageText("Did you get the cake?");
        String hash = m.createMessageHash();
        assertEquals("00:0:DIDCAKE", hash);
    }

    @Test
    public void testMessageHash_AllMessages_Loop() {
        String[] texts = {
            "Did you get the cake?",
            "Where are you? You are late! I have asked you to be on time.",
            "It is dinner time!",
            "Ok, I am leaving without you."
        };
        String[] ids = {"0011111111", "0022222222", "0033333333", "0044444444"};
        String[] expected = {"DIDCAKE", "WHERETIME", "ITTIME", "OKYOU"};

        for (int i = 0; i < texts.length; i++) {
            Message m = new Message();
            m.setMessageID(ids[i]);
            m.setNumMessagesSent(i);
            m.setMessageText(texts[i]);
            String hash = m.createMessageHash();
            String expectedHash = ids[i].substring(0, 2) + ":" + i + ":" + expected[i];
            assertEquals(expectedHash, hash);
        }
    }

    // ─────────────────────────────────────────────
    // 9. Message ID is created and valid
    // ─────────────────────────────────────────────
    @Test
    public void testMessageID_Generated() {
        Message m = new Message("+277186930", "Hello World", 0);
        assertNotNull(m.getMessageID());
        assertEquals(10, m.getMessageID().length());
    }

    @Test
    public void testMessageID_ValidLength() {
        assertTrue(msg1.checkMessageID());
    }

    // ─────────────────────────────────────────────
    // 10. Total messages sent counter
    // ─────────────────────────────────────────────
    @Test
    public void testReturnTotalMessagesSent() {
        assertEquals(2, Message.returnTotalMessagess()); // msg1 and msg4 were sent
    }

    // ─────────────────────────────────────────────
    // 11. Stored messages array correctly populated
    // ─────────────────────────────────────────────
    @Test
    public void testStoredMessagesArrayPopulated() {
        assertEquals(2, Message.getStoredMessages().size());
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                     Message.getStoredMessages().get(0).getMessageText());
        assertEquals("Ok, I am leaving without you.",
                     Message.getStoredMessages().get(1).getMessageText());
    }

    // ─────────────────────────────────────────────
    // 12. Disregarded messages array populated
    // ─────────────────────────────────────────────
    @Test
    public void testDisregardedMessagesArrayPopulated() {
        assertEquals(1, Message.getDisregardedMessages().size());
        assertEquals("Yohoooo, I am at your gate.",
                     Message.getDisregardedMessages().get(0).getMessageText());
    }

    // ─────────────────────────────────────────────
    // 13. Full report contains all sent + stored messages
    // ─────────────────────────────────────────────
    @Test
    public void testDisplayReport_ContainsAllMessages() {
        String report = Message.displayReport();
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("Where are you? You are late!"));
        assertTrue(report.contains("It is dinner time!"));
        assertTrue(report.contains("Ok, I am leaving without you."));
    }
}
