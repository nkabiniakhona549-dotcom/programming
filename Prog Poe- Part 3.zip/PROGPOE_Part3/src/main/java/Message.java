import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Message {

    private String messageID;
    private int numMessagesSent;
    private String recipient;
    private String messageText;
    private String messageHash;

    // ─────────────────────────────────────────────
    // Part 3 Arrays (no hard-coding)
    // ─────────────────────────────────────────────
    private static List<Message> sentMessages       = new ArrayList<>();
    private static List<Message> disregardedMessages = new ArrayList<>();
    private static List<Message> storedMessages     = new ArrayList<>();
    private static List<String>  messageHashes      = new ArrayList<>();
    private static List<String>  messageIDs         = new ArrayList<>();

    private static int totalMessagesSent = 0;

    // ── Constructors ──
    public Message() {}

    public Message(String recipient, String messageText, int numMessagesSent) {
        this.numMessagesSent = numMessagesSent;
        this.recipient       = recipient;
        this.messageText     = messageText;
        this.messageID       = generateMessageID();
        this.messageHash     = createMessageHash();
    }

    // ── Used when loading from JSON (all fields known) ──
    public Message(String messageID, String recipient, String messageText,
                   int numMessagesSent, String messageHash) {
        this.messageID       = messageID;
        this.recipient       = recipient;
        this.messageText     = messageText;
        this.numMessagesSent = numMessagesSent;
        this.messageHash     = messageHash;
    }

    // ─────────────────────────────────────────────
    // Generate a random 10-digit message ID
    // ─────────────────────────────────────────────
    private String generateMessageID() {
        Random random = new Random();
        long id = (long)(random.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        return String.valueOf(id);
    }

    // ─────────────────────────────────────────────
    // checkMessageID() — ID must be <= 10 characters
    // ─────────────────────────────────────────────
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    // ─────────────────────────────────────────────
    // checkRecipientCell() — must start with + and be <= 10 chars
    // ─────────────────────────────────────────────
    public String checkRecipientCell() {
        if (recipient == null || !recipient.startsWith("+") || recipient.length() > 12) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        return "Cell phone number successfully captured.";
    }

    // ─────────────────────────────────────────────
    // createMessageHash()
    // Format: first 2 digits of ID : msgNumber : FIRSTWORDLASTWORD
    // ─────────────────────────────────────────────
    public String createMessageHash() {
        if (messageID == null || messageText == null) return "";
        String firstTwo  = messageID.substring(0, Math.min(2, messageID.length()));
        String[] words   = messageText.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0].replaceAll("[^a-zA-Z0-9]", "") : "";
        String lastWord  = words.length > 1 ? words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "") : firstWord;
        return (firstTwo + ":" + numMessagesSent + ":" + (firstWord + lastWord).toUpperCase());
    }

    // ─────────────────────────────────────────────
    // SentMessage() — Send / Disregard / Store
    // ─────────────────────────────────────────────
    public String SentMessage() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nWhat would you like to do with this message?");
        System.out.println("1) Send Message");
        System.out.println("2) Disregard Message");
        System.out.println("3) Store Message to send later");
        System.out.print("Choose an option: ");
        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1":
                sentMessages.add(this);
                messageHashes.add(this.messageHash);
                messageIDs.add(this.messageID);
                totalMessagesSent++;
                return "Message successfully sent.";
            case "2":
                disregardedMessages.add(this);
                System.out.println("Press 0 to delete the message");
                scanner.nextLine();
                return "Press 0 to delete the message";
            case "3":
                storedMessages.add(this);
                messageHashes.add(this.messageHash);
                messageIDs.add(this.messageID);
                return "Message successfully stored.";
            default:
                return "Invalid option. Message not sent.";
        }
    }

    // ─────────────────────────────────────────────
    // printMessages() — all sent messages
    // ─────────────────────────────────────────────
    public static String printMessages() {
        if (sentMessages.isEmpty()) return "No messages sent yet.";
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID:   ").append(m.messageID).append("\n");
            sb.append("Message Hash: ").append(m.messageHash).append("\n");
            sb.append("Recipient:    ").append(m.recipient).append("\n");
            sb.append("Message:      ").append(m.messageText).append("\n");
            sb.append("─────────────────────────\n");
        }
        return sb.toString();
    }

    // ─────────────────────────────────────────────
    // returnTotalMessagess()
    // ─────────────────────────────────────────────
    public static int returnTotalMessagess() {
        return totalMessagesSent;
    }

    // ─────────────────────────────────────────────
    // validateMessage() — max 250 characters
    // ─────────────────────────────────────────────
    public static String validateMessage(String text) {
        if (text.length() > 250) {
            int excess = text.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
        return "Message ready to send.";
    }

    // ─────────────────────────────────────────────
    // storeMessageToFile() — saves stored messages to JSON
    // ─────────────────────────────────────────────
    public static void storeMessageToFile() {
        StringBuilder json = new StringBuilder("[\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            Message m = storedMessages.get(i);
            json.append("  {\n");
            json.append("    \"messageID\": \"").append(m.messageID).append("\",\n");
            json.append("    \"numMessagesSent\": ").append(m.numMessagesSent).append(",\n");
            json.append("    \"recipient\": \"").append(m.recipient).append("\",\n");
            json.append("    \"message\": \"").append(m.messageText.replace("\"", "\\\"")).append("\",\n");
            json.append("    \"messageHash\": \"").append(m.messageHash).append("\"\n");
            json.append("  }");
            if (i < storedMessages.size() - 1) json.append(",");
            json.append("\n");
        }
        json.append("]");
        try (FileWriter fw = new FileWriter("stored_messages.json")) {
            fw.write(json.toString());
            System.out.println("Messages saved to stored_messages.json");
        } catch (IOException e) {
            System.out.println("Error saving messages: " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────
    // loadStoredMessagesFromFile() — reads JSON into storedMessages array
    // Simple hand-rolled parser (no external library needed)
    // ─────────────────────────────────────────────
    public static void loadStoredMessagesFromFile(String filepath) {
        try {
            String content = new String(Files.readAllBytes(Paths.get(filepath)));
            // Split into individual objects by "{"
            String[] objects = content.split("\\{");
            for (String obj : objects) {
                if (!obj.contains("messageID")) continue;
                String id       = extractJsonValue(obj, "messageID");
                String recip    = extractJsonValue(obj, "recipient");
                String msgText  = extractJsonValue(obj, "message");
                String hash     = extractJsonValue(obj, "messageHash");
                int num = 0;
                try { num = Integer.parseInt(extractJsonValue(obj, "numMessagesSent")); } catch (Exception ignored) {}
                if (id != null && recip != null && msgText != null) {
                    Message m = new Message(id, recip, msgText, num, hash);
                    storedMessages.add(m);
                    messageHashes.add(hash);
                    messageIDs.add(id);
                }
            }
        } catch (IOException e) {
            System.out.println("No stored messages file found. Starting fresh.");
        }
    }

    private static String extractJsonValue(String obj, String key) {
        String search = "\"" + key + "\":";
        int idx = obj.indexOf(search);
        if (idx == -1) return null;
        int start = idx + search.length();
        // skip whitespace
        while (start < obj.length() && (obj.charAt(start) == ' ' || obj.charAt(start) == '\n')) start++;
        if (start >= obj.length()) return null;
        if (obj.charAt(start) == '"') {
            // string value
            int end = obj.indexOf('"', start + 1);
            return end == -1 ? null : obj.substring(start + 1, end);
        } else {
            // number value
            int end = start;
            while (end < obj.length() && (Character.isDigit(obj.charAt(end)) || obj.charAt(end) == '-')) end++;
            return obj.substring(start, end).trim();
        }
    }

    // ═══════════════════════════════════════════════════════════
    // PART 3 — Stored Messages Menu Methods
    // ═══════════════════════════════════════════════════════════

    // a) Display sender and recipient of all stored messages
    public static void displayStoredSenderRecipient() {
        List<Message> all = getAllMessages();
        if (all.isEmpty()) { System.out.println("No messages available."); return; }
        System.out.println("\n=== Sender & Recipient of All Messages ===");
        for (Message m : all) {
            System.out.println("Recipient: " + m.recipient + " | Message: " + m.messageText);
        }
    }

    // b) Display the longest stored message
    public static String getLongestMessage() {
        List<Message> all = getAllMessages();
        if (all.isEmpty()) return "No messages available.";
        Message longest = all.get(0);
        for (Message m : all) {
            if (m.messageText.length() > longest.messageText.length()) longest = m;
        }
        return longest.messageText;
    }

    // c) Search by message ID — return recipient and message
    public static String searchByMessageID(String id) {
        List<Message> all = getAllMessages();
        for (Message m : all) {
            if (m.messageID != null && m.messageID.equals(id)) {
                return "Recipient: " + m.recipient + "\nMessage: " + m.messageText;
            }
        }
        return "Message ID not found.";
    }

    // d) Search all messages for a particular recipient
    public static String searchByRecipient(String recipient) {
        List<Message> all = getAllMessages();
        StringBuilder sb = new StringBuilder();
        for (Message m : all) {
            if (m.recipient != null && m.recipient.equals(recipient)) {
                sb.append(m.messageText).append("\n");
            }
        }
        return sb.length() == 0 ? "No messages found for that recipient." : sb.toString().trim();
    }

    // e) Delete a message using the message hash
    public static String deleteByHash(String hash) {
        // Search in all lists
        for (int i = 0; i < sentMessages.size(); i++) {
            if (hash.equals(sentMessages.get(i).messageHash)) {
                String text = sentMessages.get(i).messageText;
                sentMessages.remove(i);
                messageHashes.remove(hash);
                return "Message: \"" + text + "\" successfully deleted.";
            }
        }
        for (int i = 0; i < storedMessages.size(); i++) {
            if (hash.equals(storedMessages.get(i).messageHash)) {
                String text = storedMessages.get(i).messageText;
                storedMessages.remove(i);
                messageHashes.remove(hash);
                return "Message: \"" + text + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    // f) Display full report of all stored messages (hash, recipient, message)
    public static String displayReport() {
        List<Message> all = getAllMessages();
        if (all.isEmpty()) return "No messages to report.";
        StringBuilder sb = new StringBuilder();
        sb.append("\n======== Message Report ========\n");
        for (Message m : all) {
            sb.append("Message Hash: ").append(m.messageHash).append("\n");
            sb.append("Recipient:    ").append(m.recipient).append("\n");
            sb.append("Message:      ").append(m.messageText).append("\n");
            sb.append("────────────────────────────────\n");
        }
        return sb.toString();
    }

    // Helper — combines sent + stored for searches/reports
    private static List<Message> getAllMessages() {
        List<Message> all = new ArrayList<>();
        all.addAll(sentMessages);
        all.addAll(storedMessages);
        return all;
    }

    // ─────────────────────────────────────────────
    // Getters
    // ─────────────────────────────────────────────
    public String getMessageID()    { return messageID; }
    public String getMessageHash()  { return messageHash; }
    public String getRecipient()    { return recipient; }
    public String getMessageText()  { return messageText; }
    public int getNumMessagesSent() { return numMessagesSent; }

    // Static array getters (for tests)
    public static List<Message> getSentMessages()        { return sentMessages; }
    public static List<Message> getStoredMessages()      { return storedMessages; }
    public static List<Message> getDisregardedMessages() { return disregardedMessages; }
    public static List<String>  getMessageHashes()       { return messageHashes; }
    public static List<String>  getMessageIDs()          { return messageIDs; }

    // ─────────────────────────────────────────────
    // Setters
    // ─────────────────────────────────────────────
    public void setMessageID(String id)   { this.messageID = id; }
    public void setRecipient(String r)    { this.recipient = r; }
    public void setMessageText(String t)  { this.messageText = t; }
    public void setNumMessagesSent(int n) { this.numMessagesSent = n; }
    public void setMessageHash(String h)  { this.messageHash = h; }

    // ─────────────────────────────────────────────
    // resetState() — clears all arrays (used in tests)
    // ─────────────────────────────────────────────
    public static void resetState() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
        totalMessagesSent = 0;
    }

    // ─────────────────────────────────────────────
    // Helper to add directly to arrays (used in tests)
    // ─────────────────────────────────────────────
    public static void addToSent(Message m) {
        sentMessages.add(m);
        messageHashes.add(m.messageHash);
        messageIDs.add(m.messageID);
        totalMessagesSent++;
    }

    public static void addToStored(Message m) {
        storedMessages.add(m);
        messageHashes.add(m.messageHash);
        messageIDs.add(m.messageID);
    }

    public static void addToDisregarded(Message m) {
        disregardedMessages.add(m);
    }
}
